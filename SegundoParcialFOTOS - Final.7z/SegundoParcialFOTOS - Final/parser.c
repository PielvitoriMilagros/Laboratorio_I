#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Ventas.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVentas LinkedList*
 * \return int
 *
 */
int parser_VentasFromText(FILE* pFile, LinkedList* pArrayListVentas)
{
    int retorno=-1;
    char bufferId[50];
    char bufferFecha[50];
    char bufferTipo[50];
    char bufferCantidad[50];
    char bufferPrecio[50];
    char bufferCuit[50];

    int flag=0;

    Ventas* pAuxVentas;

    if(pFile != NULL && pArrayListVentas != NULL)
    {
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^;];%[^;];%[^;];%[^;];%[^;];%[^\n]\n",bufferId,bufferFecha,bufferTipo,bufferCantidad,bufferPrecio,bufferCuit);
            if(flag == 0)
            {
                flag ++;
                continue;
            }
            pAuxVentas = venta_newParametros(bufferId,bufferFecha,bufferTipo,bufferCantidad,bufferPrecio,bufferCuit);
            if(pAuxVentas != NULL)
            {
                ll_add(pArrayListVentas,pAuxVentas);
                retorno = 0;
            }
        }

    }

    return retorno;
}
