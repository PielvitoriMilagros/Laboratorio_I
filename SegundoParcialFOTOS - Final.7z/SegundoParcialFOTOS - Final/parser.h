#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Ventas.h"

int parser_VentasFromText(FILE* pFile , LinkedList* pArrayListVentas);


