#include <stdio.h>
#include <stdlib.h>
#include "Vendedores.h"
#include "funciones.h"
#include "Controller.h"
#include "parser.h"
#include "LinkedList.h"



int main()
{
    int option = 0;
    int flag = 0;
    LinkedList* listaVendedores = ll_newLinkedList();
    do
    {
        printf("\nMenu:");
        printf("\n1. Cargar archivo");
        printf("\n2. Imprimir vendedores");
        printf("\n3. Calcular comisiones");
        printf("\n4. Generar archivo de comisiones para nivel");
        printf("\n5. Salir");


        getIntInRange(&option,"\nIngrese opcion: ","Error",1,5,3);
        switch(option)
        {
        case 1:
            if(flag == 0)
            {
                if(controller_loadFromText(listaVendedores) == 0)
                {
                    flag = 1;
                }
                else
                {
                    printf("\nNo se carg� el archivo\n");
                }
            }
            else
            {
                printf("\nEl archivo ya fue cargado anteriormente\n");
            }
            break;

        case 2:
            if (ll_len(listaVendedores) > 0)
            {
                controller_ListVendedores(listaVendedores);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;

/*        case 3:
            if(controller_addEmployee(listaVendedores) == 0)
            {
                printf("\nSe cargo correctamente el empleado\n");
            }
            else
            {
                printf("\nNo se pudo cargar el empleado\n");
            }
            break;
        case 4:
            if (ll_len(listaVendedores) > 0)
            {
                if(controller_editEmployee(listaVendedores) == 0)
                {
                    printf("\nEmpleado modificado\n");
                }
                else
                {
                    printf("\nNo se pudo modificar el empleado\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 5:
            if (ll_len(listaVendedores) > 0)
            {
                if(controller_removeEmployee(listaVendedores) == 0)
                {
                    printf("\nEmpleado eliminado\n");
                }
                else
                {
                    printf("\nNo se elimino el empleado\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 6:
            if (ll_len(listaVendedores) > 0)
            {
                controller_ListEmployee(listaVendedores);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 7:
            if (ll_len(listaVendedores) > 0)
            {
                controller_sortEmployee(listaVendedores);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 8:
            if(ll_len(listaVendedores)> 0)
            {
                if(controller_saveAsText("dataNuevo.csv",listaVendedores) == 0)
                {
                    printf("\nSe grabo el archivo dataNuevo.csv\n");
                }
                else
                {
                    printf("\nNo se pudo guardar el archivo\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 9:
            if(ll_len(listaVendedores)> 0)
            {
                if(controller_saveAsBinary("data.bin",listaVendedores) == 0)
                {
                    printf("\nSe grabo el archivo data.bin\n");
                }
                else
                {
                    printf("\nNo se pudo guardar el archivo\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;*/
        }
    }
    while(option != 5);
    return 0;
}
