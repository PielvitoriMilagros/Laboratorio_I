#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Vendedores.h"


int parser_VendedoresFromText(FILE* pFile , LinkedList* pArrayListVendedores);
//int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee);

//int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee);

