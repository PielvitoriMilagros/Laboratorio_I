#ifndef vendedores_H_INCLUDED
#define vendedores_H_INCLUDED

typedef struct
{
    int id;
    char nombre[128];
    char nivel[128];
    int cantidadProductosVendidos;
    float montoVendido;
}Vendedores;

Vendedores* vendedor_new(void);
Vendedores* vendedor_newParametros(char* idStr,char* nombreStr,char* nivelStr,char* cantidadProductosVendidosStr,char* montoVendidoStr);
void vendedor_delete(Vendedores* vendedor);

int vendedor_setId(Vendedores* this,int id);
int vendedor_getId(Vendedores* this,int* id);

int vendedor_setNombre(Vendedores* this,char* nombre);
int vendedor_getNombre(Vendedores* this,char* nombre);

int vendedor_setNivel(Vendedores* this,char* nivel);
int vendedor_getNivel(Vendedores* this,char* nivel);

int vendedor_setCantidadProductosVendidos(Vendedores* this,int cantidadProductosVendidos);
int vendedor_getCantidadProductosVendidos(Vendedores* this,int* cantidadProductosVendidos);

int vendedor_setMontoVendido(Vendedores* this,float montoVendido);
int vendedor_getMontoVendido(Vendedores* this,float* montoVendido);

int vendedor_compareNivel(void* pVendedor1, void* pVendedor2);

int vendedor_showVendedores(Vendedores* pVendedor);


int vendedor_nivelNoJunior(void* pVendedor);
int vendedor_nivelNoJunior(void* pVendedor);


#endif // vendedores_H_INCLUDED


