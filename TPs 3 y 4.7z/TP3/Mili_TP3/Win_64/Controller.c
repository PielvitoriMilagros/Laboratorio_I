#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Employee.h"
#include "parser.h"
#include "funciones.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListEmployee)
{
    FILE* pArch=NULL;
    int len=0;
    int retorno = -1;

    if(path != NULL && pArrayListEmployee != NULL)
    {
        pArch = fopen(path,"rw");
        if(pArch != NULL)
        {
            if(parser_EmployeeFromText(pArch,pArrayListEmployee)==0)
            {
                len = ll_len(pArrayListEmployee);
                printf("Se cargaron %d registros",len);
                retorno = 0;
            }
        }

        fclose(pArch);
    }

    return retorno;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path, LinkedList* pArrayListEmployee)
{
    FILE* pArch = NULL;
    int len=0;
    int retorno = -1;

    if(path != NULL && pArrayListEmployee != NULL)
    {
        pArch = fopen(path,"rb");
        if (pArch != NULL)
        {
            if(parser_EmployeeFromBinary(pArch,pArrayListEmployee)==0)
            {
                ll_remove(pArrayListEmployee,len-1);
                len = ll_len(pArrayListEmployee);
                printf("Se cargaron %d registros",len);
                retorno = 0;
            }
        }
        fclose(pArch);
    }

    return retorno;
}

int controller_getLastId(LinkedList* pArrayEmployee)
{
    int lastId=-1;
    int auxId=0;
    int i;
    int len;
    Employee* pEmployee;

    len=ll_len(pArrayEmployee);

    if(pArrayEmployee != NULL && len > 0)
    {
        for(i=0; i<len; i++)
        {
            pEmployee = ll_get(pArrayEmployee,i);
            employee_getId(pEmployee,&auxId);

            if(auxId > lastId)
                lastId = auxId;
        }
    }

    return lastId;
}


int controller_findById(LinkedList* pArrayEmployee, int id)
{
    int i;
    int pos=-1;
    int len;
    int auxID;

    Employee* pEmployee;
    len=ll_len(pArrayEmployee);
    if(pArrayEmployee!= NULL && len > 0 && id > 0)
    {
        for(i=0; i<len; i++)
        {
            pEmployee = ll_get(pArrayEmployee,i);
            employee_getId(pEmployee,&auxID);

            if (auxID == id)
            {
                pos=i;
                break;
            }
        }
    }

    return pos;
}


int controller_showEmployee(Employee* pEmployee)
{
    char bufferNombre[50];
    int auxId;
    int auxHoras;
    int auxSueldo;
    int retorno=-1;

    if(pEmployee != NULL)
    {
        employee_getId(pEmployee,&auxId);
        employee_getNombre(pEmployee,bufferNombre);
        employee_getHorasTrabajadas(pEmployee,&auxHoras);
        employee_getSueldo(pEmployee,&auxSueldo);

        printf("\nID: %d\nNombre: %s\nHoras Trabajadas: %d\nSueldo: %d\n",
               auxId,bufferNombre,auxHoras,auxSueldo);
        retorno=0;
    }

    return retorno;

}


/** \brief Alta de empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    int retorno=-1;
    char msgError[20]="\nValor invalido";
    int reintentos=3;

    char bufferNombre[100];
    char bufferHoras[100];
    char bufferSueldo[100];
    Employee* pEmployee;

    int auxId=0;
    char auxIdChar[10];

    if(getStringLetras(bufferNombre,"\nIngrese nombre: ",msgError,reintentos) == 0)
    {
        if(getStringNumeros(bufferHoras,"\nIngrese Horas Trabajadas: ",msgError,reintentos,-1,-1) == 0)
        {
            if(getStringNumeros(bufferSueldo,"\nIngrese Sueldo: ",msgError,reintentos,-1,-1) == 0)
            {
                auxId=controller_getLastId(pArrayListEmployee);
                auxId++;
                sprintf(auxIdChar,"%d",auxId);
                pEmployee = employee_newParametros(auxIdChar,bufferNombre,bufferHoras,bufferSueldo);

                ll_add(pArrayListEmployee,pEmployee);
                retorno=0;
            }
        }
    }

    return retorno;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    int retorno=-1;
    int opcion=0;
    char bufferId[10];
    char bufferNombre[100];
    char bufferHoras[100];
    char bufferSueldo[100];

    Employee* pEmployee;
    int pos;

    if(pArrayListEmployee != NULL)
    {
        if(getStringNumeros(bufferId,"\nIngrese ID del empleado a modificar: ","\nValor invalido",3,-1,-1) == 0)
        {
            pos=controller_findById(pArrayListEmployee,atoi(bufferId));
            if(pos != -1)
            {
                pEmployee = ll_get(pArrayListEmployee,pos);
                do
                {
                    controller_showEmployee(pEmployee);
                    printf("\n1. Modificar Nombre");
                    printf("\n2. Modificar Horas Trabajadas");
                    printf("\n3. Modificar Sueldo");
                    printf("\n4. Atras (Menu Principal)\n");

                    getIntInRange(&opcion,"\nIngrese opcion: ","\nValor Invalido",1,4,3);

                    switch(opcion)
                    {
                    case 1:
                        if (getStringLetras(bufferNombre,"\nIngrese nuevo nombre: ","\nValor invalido",3) == 0)
                        {
                            employee_setNombre(pEmployee,bufferNombre);
                            retorno=0;
                        }
                        break;
                    case 2:
                        if(getStringNumeros(bufferHoras,"\nIngrese nuevas horas trabajadas: ","\nValor invalido",3,-1,-1) == 0)
                        {
                            employee_setHorasTrabajadas(pEmployee,atoi(bufferHoras));
                            retorno=0;
                        }
                        break;
                    case 3:
                        if(getStringNumeros(bufferSueldo,"\nIngrese nuevo sueldo: ","\nValor invalido",3,-1,-1) == 0)
                        {
                            employee_setSueldo(pEmployee,atoi(bufferSueldo));
                            retorno=0;
                        }
                        break;
                    }

                }
                while(opcion!=4 || retorno != 0);
            }
            else
            {
                printf("\nNo se encontr� el ID ingresado.\n");
            }

        }
    }
    return retorno;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    int retorno=-1;
    Employee* pEmployee;
    int pos;
    char bufferId[10];

    if(pArrayListEmployee != NULL)
    {
        if(getStringNumeros(bufferId,"\nIngrese ID del empleado a eliminar: ","\nValor invalido",3,-1,-1) == 0)
        {
            pos=controller_findById(pArrayListEmployee,atoi(bufferId));
            if(pos != -1)
            {
                pEmployee = ll_pop(pArrayListEmployee,pos);
                if(pEmployee != NULL && pos >= 0)
                {
                    employee_delete(pEmployee);
                    retorno = 0;
                }
            }
        }
    }

    return retorno;
}

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{
    int retorno = -1;
    Employee* pEmployee;
    int i;
    int len=0;
    if(pArrayListEmployee != NULL)
    {
        len=ll_len(pArrayListEmployee);
        if(len > 0)
        {
            for(i=0; i<len; i++)
            {
                pEmployee = ll_get(pArrayListEmployee,i);
                controller_showEmployee(pEmployee);
                retorno=0;
            }
        }
        else
        {
            printf("\nNo se encontraron registros\n");
        }
    }
    return retorno;
}

/** \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    int retorno=-1;

    ll_sort(pArrayListEmployee,employee_compareName,1);
    controller_ListEmployee(pArrayListEmployee);

    return retorno;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path, LinkedList* pArrayListEmployee)
{
    int retorno=-1;
    int len=0;
    int i;
    int auxId;
    int auxHoras;
    int auxSueldo;
    char bufferNombre[50];
    Employee* pEmployee;

    FILE* pArch=NULL;

    if(path != NULL && pArrayListEmployee != NULL)
    {
        pArch = fopen(path,"w");

        if(pArch != NULL)
        {
            len = ll_len(pArrayListEmployee);
            if(len>0)
            {
                for(i=0; i<len; i++)
                {
                    pEmployee = ll_get(pArrayListEmployee,i);
                    employee_getId(pEmployee,&auxId);
                    employee_getNombre(pEmployee,bufferNombre);
                    employee_getHorasTrabajadas(pEmployee,&auxHoras);
                    employee_getSueldo(pEmployee,&auxSueldo);

                    if(auxId >= 0 && bufferNombre != NULL && auxHoras >= 0 && auxSueldo >= 0)
                    {
                        fprintf(pArch,"%d,%s,%d,%d\n",auxId,bufferNombre,auxHoras,auxSueldo);
                    }
                    else
                    {
                        employee_delete(pEmployee);
                    }
                }
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}

/** \brief Guarda los datos de los empleados en el archivo data.bin (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path, LinkedList* pArrayListEmployee)
{
    int retorno=-1;
    int len=0;
    int i;

    Employee* pEmployee;
    FILE* pArch=NULL;

    if(path != NULL && pArrayListEmployee != NULL)
    {
        pArch = fopen(path,"wb");
        if(pArch != NULL)
        {
            len = ll_len(pArrayListEmployee);
            if(len>0)
            {
                for(i=0; i<len; i++)
                {
                    pEmployee = ll_get(pArrayListEmployee,i);
                    fwrite(pEmployee,sizeof(Employee),1,pArch);
                }
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}

