#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"
#include "funciones.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.bin (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.bin (modo binario).
    10. Salir
*****************************************************/


int main()
{
    int option = 0;
    int flag = 0;
    LinkedList* listaEmpleados = ll_newLinkedList();
    do
    {
        printf("\nMenu:");
        printf("\n1. Cargar archivo texto");
        printf("\n2. Cargar archivo binario");
        printf("\n3. Alta de empleado");
        printf("\n4. Modificar datos de empleado");
        printf("\n5. Baja de empleado");
        printf("\n6. Listar empleados");
        printf("\n7. Ordenar empleados");
        printf("\n8. Guardar modo texto");
        printf("\n9. Guardar modo binario");
        printf("\n10. Salir");


        getIntInRange(&option,"\nIngrese opcion: ","Error",1,10,3);
        switch(option)
        {
        case 1:
            if(flag == 0)
            {
                if(controller_loadFromText("data.csv",listaEmpleados) == 0)
                {
                    flag = 1;
                }
                else
                {
                    printf("\nNo se carg� el archivo\n");
                }
            }
            else
            {
                printf("\nEl archivo ya fue cargado anteriormente\n");
            }
            break;

        case 2:
            if(flag == 0)
            {
                if(controller_loadFromBinary("data.bin",listaEmpleados) == 0)
                {
                    flag = 1;
                }
                else
                {
                    printf("\nNo se carg� el archivo\n");
                }
            }
            else
            {
                printf("\nEl archivo ya fue cargado anteriormente\n");
            }
            break;

        case 3:
            if(controller_addEmployee(listaEmpleados) == 0)
            {
                printf("\nSe cargo correctamente el empleado\n");
            }
            else
            {
                printf("\nNo se pudo cargar el empleado\n");
            }
            break;
        case 4:
            if (ll_len(listaEmpleados) > 0)
            {
                if(controller_editEmployee(listaEmpleados) == 0)
                {
                    printf("\nEmpleado modificado\n");
                }
                else
                {
                    printf("\nNo se pudo modificar el empleado\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 5:
            if (ll_len(listaEmpleados) > 0)
            {
                if(controller_removeEmployee(listaEmpleados) == 0)
                {
                    printf("\nEmpleado eliminado\n");
                }
                else
                {
                    printf("\nNo se elimino el empleado\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 6:
            if (ll_len(listaEmpleados) > 0)
            {
                controller_ListEmployee(listaEmpleados);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 7:
            if (ll_len(listaEmpleados) > 0)
            {
                controller_sortEmployee(listaEmpleados);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 8:
            if(ll_len(listaEmpleados)> 0)
            {
                if(controller_saveAsText("dataNuevo.csv",listaEmpleados) == 0)
                {
                    printf("\nSe grabo el archivo dataNuevo.csv\n");
                }
                else
                {
                    printf("\nNo se pudo guardar el archivo\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 9:
            if(ll_len(listaEmpleados)> 0)
            {
                if(controller_saveAsBinary("data.bin",listaEmpleados) == 0)
                {
                    printf("\nSe grabo el archivo data.bin\n");
                }
                else
                {
                    printf("\nNo se pudo guardar el archivo\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        }
    }
    while(option != 10);
    return 0;
}
