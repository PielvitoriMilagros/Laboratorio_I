#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Vendedores.h"
#include "funciones.h"


Vendedores* vendedor_new(void)
{
    return (Vendedores*)malloc(sizeof(Vendedores));
}


Vendedores* vendedor_newParametros(char* idStr,char* nombreStr,char* nivelStr,char* cantidadProductosVendidosStr,char* montoVendidoStr)
{
    Vendedores* newVendedor=NULL;
    Vendedores* auxVendedor=NULL;

    if(idStr != NULL && nombreStr != NULL && nivelStr != NULL && cantidadProductosVendidosStr != NULL && montoVendidoStr != NULL)
    {
        auxVendedor = vendedor_new();
        if(auxVendedor != NULL)
        {
            if(
                vendedor_setId(auxVendedor,atoi(idStr))+
                vendedor_setNombre(auxVendedor,nombreStr)+
                vendedor_setNivel(auxVendedor,nivelStr)+
                vendedor_setCantidadProductosVendidos(auxVendedor,atoi(cantidadProductosVendidosStr))+
                vendedor_setMontoVendido(auxVendedor,atof(montoVendidoStr)) == 0)
            {
                newVendedor = auxVendedor;
            }
            else
            {
                vendedor_delete(auxVendedor);
            }
        }
    }

    return newVendedor;
}

void vendedor_delete(Vendedores* this)
{
    if(this != NULL)
        free(this);
}

int vendedor_setId(Vendedores* this,int id)
{
    int retorno=-1;
    if(this != NULL && id >= 0)
    {
        this->id = id;
        retorno = 0;
    }
    return retorno;
}
int vendedor_getId(Vendedores* this,int* id)
{
    int retorno=-1;
    if(this != NULL && id != NULL)
    {
        *id = this->id;
        retorno = 0;
    }
    return retorno;
}

int vendedor_setNombre(Vendedores* this,char* nombre)
{
    int retorno=-1;
    if(this != NULL && nombre != NULL)
    {
        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;
}
int vendedor_getNombre(Vendedores* this,char* nombre)
{
    int retorno=-1;
    if(this != NULL && nombre != NULL)
    {
        strcpy(nombre,this->nombre);
        retorno = 0;
    }
    return retorno;
}

int vendedor_setNivel(Vendedores* this,char* nivel)
{
    int retorno=-1;
    if(this != NULL && nivel != NULL)
    {
        strcpy(this->nivel,nivel);
        retorno = 0;
    }
    return retorno;
}
int vendedor_getNivel(Vendedores* this,char* nivel)
{
    int retorno=-1;
    if(this != NULL && nivel != NULL)
    {
        strcpy(nivel,this->nivel);
        retorno = 0;
    }
    return retorno;
}

int vendedor_setCantidadProductosVendidos(Vendedores* this,int cantidadProductosVendidos)
{
    int retorno=-1;
    if(this != NULL && cantidadProductosVendidos >= 0)
    {
        this->cantidadProductosVendidos = cantidadProductosVendidos;
        retorno = 0;
    }
    return retorno;
}
int vendedor_getCantidadProductosVendidos(Vendedores* this,int* cantidadProductosVendidos)
{
    int retorno=-1;
    if(this != NULL && cantidadProductosVendidos != NULL)
    {
        *cantidadProductosVendidos = this->cantidadProductosVendidos;
        retorno = 0;
    }
    return retorno;
}

int vendedor_setMontoVendido(Vendedores* this,float montoVendido)
{
    int retorno=-1;
    if(this != NULL && montoVendido >= 0)
    {
        this->montoVendido = montoVendido;
        retorno = 0;
    }
    return retorno;
}
int vendedor_getMontoVendido(Vendedores* this,float* montoVendido)
{
    int retorno=-1;
    if(this != NULL && montoVendido != NULL)
    {
        *montoVendido = this->montoVendido;
        retorno = 0;
    }
    return retorno;
}



int vendedor_compareNivel(void* pVendedor1, void* pVendedor2)
{
    int orden=0;
    if(pVendedor1 != NULL && pVendedor2!=NULL)
    {
        orden = strcmp(((Vendedores*)pVendedor1)->nivel,((Vendedores*)pVendedor2)->nivel);
    }
    return orden;
}



int vendedor_showVendedores(Vendedores* pVendedor)
{
    int id;
    char nombre[128];
    char nivel[128];
    int cantidadProductosVendidos;
    float montoVendido;

    int retorno=-1;

    if(pVendedor != NULL)
    {
        vendedor_getId(pVendedor,&id);
        vendedor_getNombre(pVendedor,nombre);
        vendedor_getNivel(pVendedor,nivel);
        vendedor_getCantidadProductosVendidos(pVendedor,&cantidadProductosVendidos);
        vendedor_getMontoVendido(pVendedor,&montoVendido);

        printf("%d\t%s\t%s\t\t%d\t\t%2.f\n",id,nombre,nivel,cantidadProductosVendidos,montoVendido);
        retorno=0;
    }

    return retorno;

}


int vendedor_nivelJunior(void* pVendedor)
{
    int retorno=0;
    char nivel[128];
    vendedor_getNivel(pVendedor,nivel);

    if(stricmp(nivel,"Junior")==0)
        retorno=1;

    return retorno;
}


int vendedor_nivelNoJunior(void* pVendedor)
{
    int retorno=0;
    char nivel[128];
    vendedor_getNivel(pVendedor,nivel);

    if(stricmp(nivel,"Junior")!=0)
        retorno=1;

    return retorno;
}



