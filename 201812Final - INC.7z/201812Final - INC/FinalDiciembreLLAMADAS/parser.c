#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Vendedores.h"
#include "parser.h"


/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVendedores LinkedList*
 * \return int
 *
 */
int parser_VendedoresFromText(FILE* pFile , LinkedList* pArrayListVendedores)
{
    int retorno=-1;
    char bufferId[50];
    char bufferNombre[50];
    char bufferNivel[50];
    char bufferCantidadProductosVendidos[50];
    char bufferMontoVendido[50];
    int flag=0;

    Vendedores* pAuxVendedores;

    if(pFile != NULL && pArrayListVendedores != NULL)
    {
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",bufferId,bufferNombre,bufferNivel,bufferCantidadProductosVendidos,bufferMontoVendido);
            if(flag == 0)
            {
                flag ++;
                continue;
            }
            pAuxVendedores = vendedor_newParametros(bufferId,bufferNombre,bufferNivel,bufferCantidadProductosVendidos,bufferMontoVendido);
            if(pAuxVendedores != NULL)
            {
                ll_add(pArrayListVendedores,pAuxVendedores);
                retorno = 0;
            }
        }

    }

    return retorno;
}




/** \brief Parsea los datos los datos de los empleados desde el archivo data.bin (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
/*int parser_EmployeeFromBinary(FILE* pFile, LinkedList* pArrayListEmployee)
{
    int retorno=-1;
    Employee* pEmpleado;
    Employee auxEmpleado;

    if(pFile != NULL && pArrayListEmployee != NULL)
    {
        while(!feof(pFile))
        {
            pEmpleado = employee_new();
            fread(&auxEmpleado,sizeof(Employee),1,pFile);
            if( !employee_setId(pEmpleado,auxEmpleado.id) &&
                    !employee_setNombre(pEmpleado,auxEmpleado.nombre) &&
                    !employee_setHorasTrabajadas(pEmpleado,auxEmpleado.horasTrabajadas) &&
                    !employee_setSueldo(pEmpleado,auxEmpleado.sueldo))
            {
                ll_add(pArrayListEmployee,pEmpleado);
                retorno = 0;
            }
            else
            {
                employee_delete(pEmpleado);
            }

        }
    }

    return retorno;
}*/




