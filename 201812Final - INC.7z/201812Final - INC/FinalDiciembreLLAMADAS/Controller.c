#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Vendedores.h"
#include "parser.h"
#include "funciones.h"
#include "Controller.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayList LinkedList*
 * \param opc int 1=Clientes 2=Ventas
 * \return int
 *
 */
int controller_loadFromText(LinkedList* pArrayListVendedor)
{
    FILE* pArch=NULL;
    int len=0;
    int retorno = -1;
    char path[50];

    if(pArrayListVendedor != NULL)
    {
        if(getString(path,"\nIngrese nombre del archivo: ","\nDato invalido") == 0)
        {
            pArch = fopen(path,"rw");
            if(pArch != NULL)
            {
                if(parser_VendedoresFromText(pArch,pArrayListVendedor)==0)
                {
                    len = ll_len(pArrayListVendedor);
                    printf("Se cargaron %d registros",len);
                    retorno = 0;
                }
            }

            fclose(pArch);
        }
    }

    return retorno;
}


int controller_ListVendedores(LinkedList* pArrayListVendedores)
{
    int retorno = -1;
    Vendedores* pVendedor;
    int i;
    int len=0;
    if(pArrayListVendedores != NULL)
    {
        len=ll_len(pArrayListVendedores);
        if(len > 0)
        {
            printf("\nID\tNombre\tNivel\tCantidad Vendida\tMonto Vendido\n");
            for(i=0; i<len; i++)
            {
                pVendedor = ll_get(pArrayListVendedores,i);
                vendedor_showVendedores(pVendedor);
                retorno=0;
            }
        }
        else
        {
            printf("\nNo se encontraron registros\n");
        }
    }
    return retorno;
}





