#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Clientes.h"
#include "Ventas.h"
#include "Productos.h"

int parser_ClientesFromText(FILE* pFile , LinkedList* pArrayListClientes);
//int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee);

int parser_VentasFromText(FILE* pFile , LinkedList* pArrayListVentas);
//int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee);
