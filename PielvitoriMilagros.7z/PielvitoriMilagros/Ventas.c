#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Ventas.h"
#include "funciones.h"


Ventas* venta_new(void)
{
    return (Ventas*)malloc(sizeof(Ventas));
}

Ventas* venta_newParametros(char* idVentaStr,char* idClienteStr,char* codProducto,char* cantProducto, char* precioUnitario)
{
    Ventas* newVenta=NULL;
    Ventas* auxVenta=NULL;

    if(idVentaStr != NULL && idClienteStr != NULL && codProducto != NULL && cantProducto != NULL)
    {
        auxVenta = venta_new();
        if(auxVenta != NULL)
        {
            if(
                venta_setIdVenta(auxVenta,atoi(idVentaStr))+
                venta_setIdCliente(auxVenta,atoi(idClienteStr))+
                venta_setCodProducto(auxVenta,atoi(codProducto))+
                venta_setCantProducto(auxVenta,atoi(cantProducto))+
                venta_setPrecioUnitario(auxVenta,atof(precioUnitario)) == 0)
            {
                newVenta = auxVenta;
            }
            else
            {
                venta_delete(auxVenta);
            }
        }
    }

    return newVenta;
}

void venta_delete(Ventas* this)
{
    if(this != NULL)
        free(this);
}

int venta_setIdVenta(Ventas* this,int id_venta)
{
    int retorno=-1;
    if(this != NULL && id_venta >= 0)
    {
        this->id_venta = id_venta;
        retorno = 0;
    }
    return retorno;
}
int venta_getIdVenta(Ventas* this,int* id_venta)
{
    int retorno=-1;
    if(this != NULL && id_venta != NULL)
    {
        *id_venta = this->id_venta;
        retorno = 0;
    }
    return retorno;
}

int venta_setIdCliente(Ventas* this,int id_cliente)
{
    int retorno=-1;
    if(this != NULL && id_cliente >= 0)
    {
        this->id_cliente = id_cliente;
        retorno = 0;
    }
    return retorno;
}
int venta_getIdCliente(Ventas* this,int* id_cliente)
{
    int retorno=-1;
    if(this != NULL && id_cliente != NULL)
    {
        *id_cliente = this->id_cliente;
        retorno = 0;
    }
    return retorno;
}

int venta_setCodProducto(Ventas* this,int codProducto)
{
    int retorno=-1;
    if(this != NULL && codProducto >= 0)
    {
        this->codProducto = codProducto;
        retorno = 0;
    }
    return retorno;
}
int venta_getCodProducto(Ventas* this,int* codProducto)
{
    int retorno=-1;
    if(this != NULL && codProducto != NULL)
    {
        *codProducto = this->codProducto;
        retorno = 0;
    }
    return retorno;
}

int venta_setCantProducto(Ventas* this,int cantProducto)
{
    int retorno=-1;
    if(this != NULL && cantProducto >= 0)
    {
        this->cantProducto = cantProducto;
        retorno = 0;
    }
    return retorno;
}
int venta_getCantProducto(Ventas* this,int* cantProducto)
{
    int retorno=-1;
    if(this != NULL && cantProducto != NULL)
    {
        *cantProducto = this->cantProducto;
        retorno = 0;
    }
    return retorno;
}

int venta_setPrecioUnitario(Ventas* this,float precioUnitario)
{
    int retorno=-1;
    if(this != NULL && precioUnitario >= 0)
    {
        this->precioUnitario = precioUnitario;
        retorno = 0;
    }
    return retorno;
}
int venta_getPrecioUnitario(Ventas* this,float* precioUnitario)
{
    int retorno=-1;
    if(this != NULL && precioUnitario != NULL)
    {
        *precioUnitario = this->precioUnitario;
        retorno = 0;
    }
    return retorno;
}
