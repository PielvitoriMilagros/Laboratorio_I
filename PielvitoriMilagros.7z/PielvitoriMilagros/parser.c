#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Clientes.h"
#include "Ventas.h"
#include "Productos.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListClientes LinkedList*
 * \return int
 *
 */
int parser_ClientesFromText(FILE* pFile , LinkedList* pArrayListClientes)
{
    int retorno=-1;
    char bufferId[50];
    char bufferNombre[50];
    char bufferApellido[50];
    char bufferDni[50];
    int flag=0;

    Clientes* pAuxClientes;

    if(pFile != NULL && pArrayListClientes != NULL)
    {
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",bufferId,bufferNombre,bufferApellido,bufferDni);
            if(flag == 0)
            {
                flag ++;
                continue;
            }
            pAuxClientes = cliente_newParametros(bufferId,bufferNombre,bufferApellido,bufferDni);
            if(pAuxClientes != NULL)
            {
                ll_add(pArrayListClientes,pAuxClientes);
                retorno = 0;
            }
        }

    }

    return retorno;
}


int parser_VentasFromText(FILE* pFile , LinkedList* pArrayListVentas)
{
    int retorno=-1;
    char bufferIdVenta[50];
    char bufferIdCliente[50];
    char bufferCodProducto[50];
    char bufferCantidad[50];
    char bufferPrecio[50];
    int flag=0;

    Ventas* pAuxVentas;

    if(pFile != NULL && pArrayListVentas != NULL)
    {
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",bufferIdVenta,bufferIdCliente,bufferCodProducto,bufferCantidad,bufferPrecio);
            if(flag == 0)
            {
                flag ++;
                continue;
            }
            pAuxVentas = venta_newParametros(bufferIdVenta,bufferIdCliente,bufferCodProducto,bufferCantidad,bufferPrecio);
            if(pAuxVentas != NULL)
            {
                ll_add(pArrayListVentas,pAuxVentas);
                retorno = 0;
            }
        }

    }

    return retorno;
}




/** \brief Parsea los datos los datos de los empleados desde el archivo data.bin (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
/*int parser_EmployeeFromBinary(FILE* pFile, LinkedList* pArrayListEmployee)
{
    int retorno=-1;
    Employee* pEmpleado;
    Employee auxEmpleado;

    if(pFile != NULL && pArrayListEmployee != NULL)
    {
        while(!feof(pFile))
        {
            pEmpleado = employee_new();
            fread(&auxEmpleado,sizeof(Employee),1,pFile);
            if( !employee_setId(pEmpleado,auxEmpleado.id) &&
                    !employee_setNombre(pEmpleado,auxEmpleado.nombre) &&
                    !employee_setHorasTrabajadas(pEmpleado,auxEmpleado.horasTrabajadas) &&
                    !employee_setSueldo(pEmpleado,auxEmpleado.sueldo))
            {
                ll_add(pArrayListEmployee,pEmpleado);
                retorno = 0;
            }
            else
            {
                employee_delete(pEmpleado);
            }

        }
    }

    return retorno;
}*/



