#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Clientes.h"
#include "Ventas.h"
#include "Productos.h"
#include "parser.h"
#include "funciones.h"
#include "Controller.h"

#define MENORPRODUCTO 1000
#define MAYORPRODUCTO 1002


/*******************          C  L  I  E  N  T  E  S            ***********************/

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayList LinkedList*
 * \param opc int 1=Clientes 2=Ventas
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayList,int opc)
{
    FILE* pArch=NULL;
    int len=0;
    int retorno = -1;

    if(path != NULL && pArrayList != NULL)
    {
        pArch = fopen(path,"rw");
        if(pArch != NULL)
        {
            if(opc == 1)
            {
                if(parser_ClientesFromText(pArch,pArrayList)==0)
                    retorno = 0;
            }
            else
            {
                if(parser_VentasFromText(pArch,pArrayList)==0)
                    retorno = 0;

            }
            if(retorno == 0)
            {
                len = ll_len(pArrayList);
                printf("Se cargaron %d registros del archivo %s\n",len,path);
            }
        }

        fclose(pArch);
    }

    return retorno;
}

int controller_addCliente(LinkedList* pArrayListClientes)
{
    int retorno=-1;
    char msgError[20]="\nValor invalido";
    int reintentos=3;

    char bufferNombre[100];
    char bufferApellido[100];
    char bufferDni[100];
    Clientes* pCliente;

    int auxId=0;
    char auxIdChar[10];

    if(getStringLetras(bufferNombre,"\nIngrese nombre: ",msgError,reintentos) == 0)
    {
        if(getStringLetras(bufferApellido,"\nIngrese Apellido: ",msgError,reintentos) == 0)
        {
            if(getStringNumeros(bufferDni,"\nIngrese Dni: ",msgError,reintentos,-1,-1) == 0)
            {
                auxId=controller_getLastIdClientes(pArrayListClientes);
                auxId++;
                sprintf(auxIdChar,"%d",auxId);
                pCliente = cliente_newParametros(auxIdChar,bufferNombre,bufferApellido,bufferDni);

                ll_add(pArrayListClientes,pCliente);
                controller_saveAsTextClientes(pArrayListClientes);
                retorno=0;
            }
        }
    }
    return retorno;
}

int controller_getLastIdClientes(LinkedList* pArrayListClientes)
{
    int lastId=-1;
    int auxId=0;
    int i;
    int len;
    Clientes* pCliente;

    len=ll_len(pArrayListClientes);

    if(pArrayListClientes != NULL && len > 0)
    {
        for(i=0; i<len; i++)
        {
            pCliente = ll_get(pArrayListClientes,i);
            cliente_getId(pCliente,&auxId);

            if(auxId > lastId)
                lastId = auxId;
        }
    }

    return lastId;
}


int controller_editCliente(LinkedList* pArrayListClientes)
{
    int retorno=-1;
    int opcion=0;
    char bufferId[10];
    char bufferNombre[100];
    char bufferApellido[100];
    char bufferDni[100];

    Clientes* pCliente;
    int pos;

    if(pArrayListClientes != NULL)
    {
        if(getStringNumeros(bufferId,"\nIngrese ID del cliente a modificar: ","\nValor invalido",3,-1,-1) == 0)
        {
            pos=controller_findByIdCliente(pArrayListClientes,atoi(bufferId));
            if(pos != -1)
            {
                pCliente = ll_get(pArrayListClientes,pos);
                do
                {
                    controller_showCliente(pCliente,1);
                    printf("\n1. Modificar Nombre");
                    printf("\n2. Modificar Apellido");
                    printf("\n3. Modificar Dni");
                    printf("\n4. Atras (Menu Principal)\n");

                    getIntInRange(&opcion,"\nIngrese opcion: ","\nValor Invalido",1,4,3);

                    switch(opcion)
                    {
                    case 1:
                        if (getStringLetras(bufferNombre,"\nIngrese nuevo nombre: ","\nValor invalido",3) == 0)
                        {
                            cliente_setNombre(pCliente,bufferNombre);
                            retorno=0;
                        }
                        break;
                    case 2:
                        if (getStringLetras(bufferApellido,"\nIngrese nuevo apellido: ","\nValor invalido",3) == 0)
                        {
                            cliente_setApellido(pCliente,bufferApellido);
                            retorno=0;
                        }
                        break;
                    case 3:
                        if(getStringNumeros(bufferDni,"\nIngrese nuevo DNI: ","\nValor invalido",3,-1,-1) == 0)
                        {
                            cliente_setDni(pCliente,atoi(bufferDni));
                            retorno=0;
                        }
                        break;
                    }

                }
                while(opcion != 4);
                controller_saveAsTextClientes(pArrayListClientes);
            }
            else
            {
                printf("\nNo se encontr� el ID ingresado.\n");
            }

        }
    }
    return retorno;
}


int controller_findByIdCliente(LinkedList* pArrayListClientes, int id)
{
    int i;
    int pos=-1;
    int len;
    int auxID;

    Clientes* pCliente;
    len=ll_len(pArrayListClientes);
    if(pArrayListClientes!= NULL && len > 0 && id > 0)
    {
        for(i=0; i<len; i++)
        {
            pCliente = ll_get(pArrayListClientes,i);
            cliente_getId(pCliente,&auxID);

            if (auxID == id)
            {
                pos=i;
                break;
            }
        }
    }

    return pos;
}


int controller_showCliente(Clientes* pCliente,int llamado)
{
    int auxId;
    char bufferNombre[50];
    char bufferApellido[50];
    int auxDni;

    int retorno=-1;

    if(pCliente != NULL)
    {
        cliente_getId(pCliente,&auxId);
        cliente_getNombre(pCliente,bufferNombre);
        cliente_getApellido(pCliente,bufferApellido);
        cliente_getDni(pCliente,&auxDni);

        if(llamado == 1)
        {
            printf("\nID: %d\nNombre: %s\nApellido: %s\nDNI: %d\n",
                   auxId,bufferNombre,bufferApellido,auxDni);
        }
        else
        {
            printf("%d\t%s\t%s\t\t%d\n",auxId,bufferNombre,bufferApellido,auxDni);
        }
        retorno=0;
    }

    return retorno;

}


int controller_removeCliente(LinkedList* pArrayListClientes,LinkedList* pArrayListVentas)
{
    int retorno=-1;
    Clientes* pCliente;
    Ventas* pVenta;
    int pos;
    char bufferId[10];
    int i;
    int lenVentas;
    int auxClienteDeVenta;
    int ventaAsociada;
    lenVentas=ll_len(pArrayListVentas);

    if(pArrayListClientes != NULL)
    {
        if(getStringNumeros(bufferId,"\nIngrese ID del cliente a eliminar: ","\nValor invalido",3,-1,-1) == 0)
        {
            pos=controller_findByIdCliente(pArrayListClientes,atoi(bufferId));

            if(pos != -1)
            {
                ventaAsociada=0;
                for(i=0; i<=lenVentas; i++)
                {
                    pVenta=ll_get(pArrayListVentas,i);
                    venta_getIdCliente(pVenta,&auxClienteDeVenta);

                    if(atoi(bufferId) == auxClienteDeVenta)
                    {
                        ventaAsociada++;
                        break;
                    }
                }

                if(ventaAsociada == 0)
                {
                    pCliente = ll_pop(pArrayListClientes,pos);
                    if(pCliente != NULL && pos >= 0)
                    {
                        cliente_delete(pCliente);
                        retorno = 0;
                        controller_saveAsTextClientes(pArrayListClientes);
                    }
                }
                else
                {
                    printf("\nTiene venta/s asociada/s");
                }
            }
        }
    }

    return retorno;
}


int controller_sortClientes(LinkedList* pArrayListClientes)
{
    int retorno=-1;

    ll_sort(pArrayListClientes,cliente_compareSurname,1);
    controller_ListClientes(pArrayListClientes);

    return retorno;
}

int controller_ListClientes(LinkedList* pArrayListClientes)
{
    int retorno = -1;
    Clientes* pCliente;
    int i;
    int len=0;
    if(pArrayListClientes != NULL)
    {
        len=ll_len(pArrayListClientes);
        if(len > 0)
        {
            printf("Id\tNombre\tApellido\tDNI\n");
            for(i=0; i<len; i++)
            {
                pCliente = ll_get(pArrayListClientes,i);
                controller_showCliente(pCliente,2);
                retorno=0;
            }
        }
        else
        {
            printf("\nNo se encontraron registros\n");
        }
    }
    return retorno;
}


/*******************          V  E  N  T  A  S            ***********************/


int controller_addVenta(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos)
{
    int retorno=-1;
    char msgError[20]="\nValor invalido";
    int reintentos=3;

    char bufferIdCliente[100];
    char bufferCodProducto[100];
    char bufferCantidad[100];
    char bufferPrecioUnitario[100];

    float auxPrecioUnitario;

    Ventas* pVenta;
    Productos* pProducto;
    int pos;
    int posCliente;

    int auxId=0;
    char auxIdChar[10];

    if(getStringNumeros(bufferIdCliente,"\nIngrese ID del cliente: ",msgError,reintentos,-1,-1) == 0)
    {
        posCliente=controller_findByIdCliente(pArrayListClientes,atoi(bufferIdCliente));
        if(posCliente != -1)
        {

            if(getStringNumeros(bufferCodProducto,"\nIngrese codigo del producto a comprar: ","\nProducto Inexistente",reintentos,MENORPRODUCTO,MAYORPRODUCTO) == 0)
            {
                pos = controller_findByIdProducto(pArrayProductos,atoi(bufferCodProducto));
                if(pos!=-1)
                {
                    pProducto = ll_get(pArrayProductos,pos);
                    producto_getPrecioUnitario(pProducto,&auxPrecioUnitario);
                    sprintf(bufferPrecioUnitario,"%f",auxPrecioUnitario);

                    if(getStringNumeros(bufferCantidad,"\nIngrese Cantidad: ",msgError,reintentos,-1,-1) == 0)
                    {
                        auxId=controller_getLastIdVentas(pArrayListVentas);
                        auxId++;
                        sprintf(auxIdChar,"%d",auxId);
                        pVenta = venta_newParametros(auxIdChar,bufferIdCliente,bufferCodProducto,bufferCantidad,bufferPrecioUnitario);

                        ll_add(pArrayListVentas,pVenta);
                        controller_saveAsTextVentas(pArrayListVentas);
                        retorno=0;
                    }
                }
            }
        }
    }
    return retorno;
}

int controller_getLastIdVentas(LinkedList* pArrayListVentas)
{
    int lastId=-1;
    int auxId=0;
    int i;
    int len;
    Ventas* pVenta;

    len=ll_len(pArrayListVentas);

    if(pArrayListVentas != NULL && len > 0)
    {
        for(i=0; i<len; i++)
        {
            pVenta = ll_get(pArrayListVentas,i);
            venta_getIdVenta(pVenta,&auxId);

            if(auxId > lastId)
                lastId = auxId;
        }
    }

    return lastId;
}


int controller_removeVenta(LinkedList* pArrayListVentas)
{
    int retorno=-1;
    Ventas* pVenta;
    int pos;
    char bufferId[10];

    if(pArrayListVentas != NULL)
    {
        if(getStringNumeros(bufferId,"\nIngrese ID de la venta a eliminar: ","\nValor invalido",3,-1,-1) == 0)
        {
            pos=controller_findByIdVenta(pArrayListVentas,atoi(bufferId));
            if(pos != -1)
            {
                pVenta = ll_pop(pArrayListVentas,pos);
                if(pVenta != NULL && pos >= 0)
                {
                    venta_delete(pVenta);
                    controller_saveAsTextVentas(pArrayListVentas);
                    retorno = 0;
                }
            }
        }
    }

    return retorno;
}

int controller_findByIdVenta(LinkedList* pArrayListVentas, int id)
{
    int i;
    int pos=-1;
    int len;
    int auxID;

    Ventas* pVentas;
    len=ll_len(pArrayListVentas);
    if(pArrayListVentas!= NULL && len > 0 && id > 0)
    {
        for(i=0; i<len; i++)
        {
            pVentas = ll_get(pArrayListVentas,i);
            venta_getIdVenta(pVentas,&auxID);

            if (auxID == id)
            {
                pos=i;
                break;
            }
        }
    }

    return pos;
}


int controller_ListVentas(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos)
{
    int retorno = -1;
    Ventas* pVenta;

    int i;


    int len=0;
    if(pArrayListVentas != NULL)
    {
        len=ll_len(pArrayListVentas);
        if(len > 0)
        {
            printf("Id\tNombre Cliente\tApellido Cliente\tDNI Cliente\tCodigo Producto\tMonto Facturado\n");
            for(i=0; i<len; i++)
            {
                pVenta = ll_get(pArrayListVentas,i);
                controller_showVenta(pVenta,pArrayListClientes,pArrayProductos);

                /*               venta_getIdVenta(pVenta,&auxIdVenta);

                               venta_getIdCliente(pVenta,&idCliente);
                               iCliente=controller_findByIdCliente(pArrayListClientes,idCliente);
                               pCliente = ll_get(pArrayListClientes,iCliente);
                               cliente_getNombre(pCliente,nombreCliente);
                               cliente_getApellido(pCliente,apellidoCliente);
                               cliente_getDni(pCliente,&auxDniCliente);

                               venta_getCodProducto(pVenta,&idProducto);
                               venta_getPrecioUnitario(pVenta,&precioUnitario);
                               venta_getCantProducto(pVenta,&cantidad);

                               montoFacturado = cantidad * precioUnitario;


                               printf("%d\t%s\t\t%s\t\t\t%d\t%d\t%.2f\n",auxIdVenta,nombreCliente,apellidoCliente,auxDniCliente,idProducto,montoFacturado);*/
                retorno=0;
            }
        }
        else
        {
            printf("\nNo se encontraron registros\n");
        }
    }
    return retorno;
}

int controller_showVenta(Ventas* pVenta,LinkedList* pArrayListClientes,LinkedList* pArrayProductos)
{
    int retorno=-1;
    Clientes* pCliente;

    int auxIdVenta;
    int idCliente;
    int idProducto;
    int cantidad;

    int iCliente;
    char nombreCliente[50];
    char apellidoCliente[50];
    int auxDniCliente;

    float precioUnitario;
    float montoFacturado;

    if(pVenta != NULL && pArrayListClientes!=NULL && pArrayProductos != NULL)
    {

        venta_getIdVenta(pVenta,&auxIdVenta);

        venta_getIdCliente(pVenta,&idCliente);
        iCliente=controller_findByIdCliente(pArrayListClientes,idCliente);
        pCliente = ll_get(pArrayListClientes,iCliente);
        cliente_getNombre(pCliente,nombreCliente);
        cliente_getApellido(pCliente,apellidoCliente);
        cliente_getDni(pCliente,&auxDniCliente);

        venta_getCodProducto(pVenta,&idProducto);
        venta_getPrecioUnitario(pVenta,&precioUnitario);
        venta_getCantProducto(pVenta,&cantidad);

        montoFacturado = cantidad * precioUnitario;


        printf("%d\t%s\t\t%s\t\t\t%d\t%d\t\t%.2f\n",auxIdVenta,nombreCliente,apellidoCliente,auxDniCliente,idProducto,montoFacturado);
        retorno=0;

    }
    return retorno;
}


int controller_ListVentasPorProducto(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos)
{
    int retorno=-1;
    char bufferCodProducto[50];
    int auxCodProducto;
    int iProducto;
    int i;
    int len;
    int flag=0;

    Ventas* pVenta;
    len=ll_len(pArrayListVentas);

    if(pArrayListVentas!=NULL && pArrayListClientes!=NULL && pArrayProductos!=NULL)
    {
        if(getStringNumeros(bufferCodProducto,"\nIngrese codigo del producto: ","\nProducto Inexistente",3,MENORPRODUCTO,MAYORPRODUCTO) == 0)
        {
            iProducto=controller_findByIdProducto(pArrayProductos,atoi(bufferCodProducto));
            if(iProducto != -1)
            {
                for(i=0; i<len; i++)
                {
                    pVenta=ll_get(pArrayListVentas,i);
                    venta_getCodProducto(pVenta,&auxCodProducto);

                    if(auxCodProducto==atoi(bufferCodProducto))
                    {
                        if(flag==0)
                            printf("Id\tNombre Cliente\tApellido Cliente\tDNI Cliente\tCodigo Producto\tMonto Facturado\n");
                        controller_showVenta(pVenta,pArrayListClientes,pArrayProductos);
                        flag++;
                    }
                }
                if(flag==0)
                    printf("\nNo se encontraron ventas para el producto\n");
            }
        }
    }

    return retorno;
}





/*******************          P  R  O  D  U  C  T  O  S            ***********************/

int controller_findByIdProducto(LinkedList* pArrayProductos, int id)
{
    int i;
    int pos=-1;
    int len;
    int auxID;

    Productos* pProducto;
    len=ll_len(pArrayProductos);
    if(pArrayProductos!= NULL && len > 0 && id > 0)
    {
        for(i=0; i<len; i++)
        {
            pProducto = ll_get(pArrayProductos,i);
            producto_getId(pProducto,&auxID);

            if (auxID == id)
            {
                pos=i;
                break;
            }
        }
    }

    return pos;
}


int controller_addProductos(LinkedList* pArrayProductos)
{

    int retorno=-1;


    Productos* pProducto;

    pProducto = producto_newParametros("1000","TV_LG_32","8999.99");
    ll_add(pArrayProductos,pProducto);

    pProducto = producto_newParametros("1001","PS4","12999.99");
    ll_add(pArrayProductos,pProducto);

    pProducto = producto_newParametros("1002","IPHONE7","19480.99");
    ll_add(pArrayProductos,pProducto);

    retorno=0;

    return retorno;


}


/*****************************************************************************************/

int controller_saveAsText(char* path, LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos)
{
    int retorno=-1;
    int len=0;
    int i;
    Clientes* pCliente;
    Ventas* pVenta;

    int auxIdVenta;
    int idCliente;
    int idProducto;
    int cantidad;

    int iCliente;
    char nombreCliente[50];
    char apellidoCliente[50];
    int auxDniCliente;

    float precioUnitario;
    float montoFacturado;



    FILE* pArch=NULL;

    if(path != NULL && pArrayListVentas != NULL && pArrayListClientes != NULL && pArrayProductos != NULL)
    {
        pArch = fopen(path,"w");

        if(pArch != NULL)
        {
            len = ll_len(pArrayListVentas);
            if(len>0)
            {
                fprintf(pArch,"Id\tNombre Cliente\tApellido Cliente\tDNI Cliente\tCodigo Producto\tMonto Facturado\n");
                for(i=0; i<len; i++)
                {
                    pVenta = ll_get(pArrayListVentas,i);
                    venta_getIdVenta(pVenta,&auxIdVenta);

                    venta_getIdCliente(pVenta,&idCliente);
                    iCliente=controller_findByIdCliente(pArrayListClientes,idCliente);
                    pCliente = ll_get(pArrayListClientes,iCliente);
                    cliente_getNombre(pCliente,nombreCliente);
                    cliente_getApellido(pCliente,apellidoCliente);
                    cliente_getDni(pCliente,&auxDniCliente);

                    venta_getCodProducto(pVenta,&idProducto);
                    venta_getPrecioUnitario(pVenta,&precioUnitario);
                    venta_getCantProducto(pVenta,&cantidad);

                    montoFacturado = cantidad * precioUnitario;


                    fprintf(pArch,"%d\t%s\t\t%s\t\t\t%d\t%d\t\t%.2f\n",auxIdVenta,nombreCliente,apellidoCliente,auxDniCliente,idProducto,montoFacturado);
                    retorno=0;
                }
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}


int controller_ListVentasPorCliente(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos)
{
    int retorno=-1;

    int i;
    int j;
    int lenVentas;
    int lenClientes;

    int auxIdCliente;
    char bufferNombre[50];
    char bufferApellido[50];

    int auxClienteDeVenta;
    float auxPrecioUnitario;
    int auxCantidadProducto;

    float montoFacturado;
    float acumMF;
    int acumCantVentas;

    Ventas* pVenta;
    Clientes* pCliente;


    lenVentas=ll_len(pArrayListVentas);
    lenClientes=ll_len(pArrayListClientes);

    if(pArrayListVentas!=NULL && pArrayListClientes!=NULL && pArrayProductos!=NULL)
    {
        printf("\nIdCliente\tNombre\tApellido\tCantidad Compras\tMonto Total\n");
        for(i=0; i<=lenClientes; i++)
        {
            pCliente=ll_get(pArrayListClientes,i);
            cliente_getId(pCliente,&auxIdCliente);
            cliente_getNombre(pCliente,bufferNombre);
            cliente_getApellido(pCliente,bufferApellido);

            montoFacturado=0;
            acumMF=0;
            acumCantVentas=0;

            for(j=0; j<=lenVentas; j++)
            {
                pVenta=ll_get(pArrayListVentas,j);
                venta_getIdCliente(pVenta,&auxClienteDeVenta);

                if(auxIdCliente == auxClienteDeVenta)
                {
                    venta_getPrecioUnitario(pVenta,&auxPrecioUnitario);
                    venta_getCantProducto(pVenta,&auxCantidadProducto);
                    montoFacturado = auxPrecioUnitario * auxCantidadProducto;

                    acumCantVentas++;
                    acumMF+=montoFacturado;
                }
            }

            printf("%d\t\t%s\t%s\t\t\t%d\t\t%.2f\n",auxIdCliente,bufferNombre,bufferApellido,acumCantVentas,acumMF);
        }

    }

    return retorno;
}



int controller_saveAsTextClientes(LinkedList* pArrayListClientes)
{
    int retorno=-1;

    int len=0;
    int i;
    int auxId;
    char bufferNombre[50];
    char bufferApellido[50];
    int auxDni;

    Clientes* pCliente;

    FILE* pArch=NULL;

    if(pArrayListClientes != NULL)
    {
        pArch = fopen("clientes.txt","w");

        if(pArch != NULL)
        {
            len = ll_len(pArrayListClientes);
            if(len>0)
            {
                for(i=0; i<len; i++)
                {
                    pCliente = ll_get(pArrayListClientes,i);
                    cliente_getId(pCliente,&auxId);
                    cliente_getNombre(pCliente,bufferNombre);
                    cliente_getApellido(pCliente,bufferApellido);
                    cliente_getDni(pCliente,&auxDni);

                    if(auxId >= 0 && bufferNombre != NULL && bufferApellido != NULL && auxDni >= 0)
                    {
                        fprintf(pArch,"%d,%s,%s,%d\n",auxId,bufferNombre,bufferApellido,auxDni);
                    }
                    else
                    {
                        cliente_delete(pCliente);
                    }
                }
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}

int controller_saveAsTextVentas(LinkedList* pArrayListVentas)
{
    int retorno=-1;

    int len=0;
    int i;
    int id_venta;
    int id_cliente;
    int codProducto;
    int cantProducto;
    float precioUnitario;

    Ventas* pVenta;

    FILE* pArch=NULL;

    if(pArrayListVentas != NULL)
    {
        pArch = fopen("ventas.txt","w");

        if(pArch != NULL)
        {
            len = ll_len(pArrayListVentas);
            if(len>0)
            {
                for(i=0; i<len; i++)
                {
                    pVenta = ll_get(pArrayListVentas,i);
                    venta_getIdVenta(pVenta,&id_venta);
                    venta_getIdCliente(pVenta,&id_cliente);
                    venta_getCodProducto(pVenta,&codProducto);
                    venta_getCantProducto(pVenta,&cantProducto);
                    venta_getPrecioUnitario(pVenta,&precioUnitario);


                    if(id_venta >= 0 && id_cliente >= 0 && codProducto >= 0 && cantProducto >= 0 && precioUnitario >= 0)
                    {
                        fprintf(pArch,"%d,%d,%d,%d,%f\n",id_venta,id_cliente,codProducto,cantProducto,precioUnitario);
                    }
                    else
                    {
                        venta_delete(pVenta);
                    }
                }
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}
