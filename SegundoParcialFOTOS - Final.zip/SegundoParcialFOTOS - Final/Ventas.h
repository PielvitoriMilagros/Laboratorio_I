#ifndef venta_H_INCLUDED
#define venta_H_INCLUDED
typedef struct
{
    int id;
    char fechaVenta[10];
    char tipoFoto[15];
    int cantidad;
    float precioUnitario;
    char cuitCliente[25];
}Ventas;

Ventas* venta_new(void);
Ventas* venta_newParametros(char* idStr,char* fechaStr,char* tipoFotoStr,char* cantStr,char* precioStr,char* cuitStr);
void venta_delete(Ventas* venta);

int venta_setId(Ventas* this,int id);
int venta_getId(Ventas* this,int* id);

char venta_setFechaVenta(Ventas* this,char* fechaVenta);
char venta_getFechaVenta(Ventas* this,char* fechaVenta);

char venta_setTipoFoto(Ventas* this,char* tipoFoto);
char venta_getTipoFoto(Ventas* this,char* tipoFoto);

int venta_setCantidad(Ventas* this,int cantidad);
int venta_getCantidad(Ventas* this,int* cantidad);

float venta_setPrecioUnitario(Ventas* this,float precioUnitario);
float venta_getPrecioUnitario(Ventas* this,float* precioUnitario);

char venta_setCuitCliente(Ventas* this,char* cuitCliente);
char venta_getCuitCliente(Ventas* this,char* cuitCliente);

/** int venta_compareName(void* pEmployee1, void* pEmployee2);**/
#endif // venta_H_INCLUDED
