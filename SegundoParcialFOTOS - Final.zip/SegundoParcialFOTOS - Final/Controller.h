#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Ventas.h"
#include "parser.h"
#include "funciones.h"


int controller_loadFromText(char* path , LinkedList* pArrayListVentas);
/*int controller_loadFromBinary(char* path , LinkedList* pArrayListVentas);
int controller_addVentas(LinkedList* pArrayListVentas);
int controller_editVentas(LinkedList* pArrayListVentas);
int controller_removeVentas(LinkedList* pArrayListVentas);
int controller_ListVentas(LinkedList* pArrayListVentas);
int controller_sortVentas(LinkedList* pArrayListVentas);
int controller_saveAsBinary(char* path , LinkedList* pArrayListVentas);
int controller_getLastId(LinkedList* pArrayVentas);
int controller_findById(LinkedList* pArrayVentas, int id);*/

int controller_saveAsText(char* path , LinkedList* pArrayListVentas);

int controller_validaCantidadFotos(void* pVenta);
int controller_mayorACientoCincuenta(void* pVenta);
int controller_mayorATrescientos(void* pVenta);
int controller_cantidadPolariod(void* pVenta);




