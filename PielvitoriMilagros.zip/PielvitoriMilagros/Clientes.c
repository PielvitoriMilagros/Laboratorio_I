#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Clientes.h"
#include "funciones.h"


Clientes* cliente_new(void)
{
    return (Clientes*)malloc(sizeof(Clientes));
}


Clientes* cliente_newParametros(char* idStr,char* nombreStr,char* apellidoStr,char* dniStr)
{
    Clientes* newCliente=NULL;
    Clientes* auxCliente=NULL;

    if(idStr != NULL && nombreStr != NULL && apellidoStr != NULL && dniStr != NULL)
    {
        auxCliente = cliente_new();
        if(auxCliente != NULL)
        {
            if(
                cliente_setId(auxCliente,atoi(idStr))+
                cliente_setNombre(auxCliente,nombreStr)+
                cliente_setApellido(auxCliente,apellidoStr)+
                cliente_setDni(auxCliente,atoi(dniStr)) == 0)
            {
                newCliente = auxCliente;
            }
            else
            {
                cliente_delete(auxCliente);
            }
        }
    }

    return newCliente;
}

void cliente_delete(Clientes* this)
{
    if(this != NULL)
        free(this);
}

int cliente_setId(Clientes* this,int id)
{
    int retorno=-1;
    if(this != NULL && id >= 0)
    {
        this->id = id;
        retorno = 0;
    }
    return retorno;
}
int cliente_getId(Clientes* this,int* id)
{
    int retorno=-1;
    if(this != NULL && id != NULL)
    {
        *id = this->id;
        retorno = 0;
    }
    return retorno;
}

int cliente_setNombre(Clientes* this,char* nombre)
{
    int retorno=-1;
    if(this != NULL && nombre != NULL)
    {
        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;
}
int cliente_getNombre(Clientes* this,char* nombre)
{
    int retorno=-1;
    if(this != NULL && nombre != NULL)
    {
        strcpy(nombre,this->nombre);
        retorno = 0;
    }
    return retorno;
}

int cliente_setApellido(Clientes* this,char* apellido)
{
    int retorno=-1;
    if(this != NULL && apellido != NULL)
    {
        strcpy(this->apellido,apellido);
        retorno = 0;
    }
    return retorno;
}
int cliente_getApellido(Clientes* this,char* apellido)
{
    int retorno=-1;
    if(this != NULL && apellido != NULL)
    {
        strcpy(apellido,this->apellido);
        retorno = 0;
    }
    return retorno;
}

int cliente_setDni(Clientes* this,int dni)
{
    int retorno=-1;
    if(this != NULL && dni >= 0)
    {
        this->dni = dni;
        retorno = 0;
    }
    return retorno;
}
int cliente_getDni(Clientes* this,int* dni)
{
    int retorno=-1;
    if(this != NULL && dni != NULL)
    {
        *dni = this->dni;
        retorno = 0;
    }
    return retorno;
}



int cliente_compareSurname(void* pCliente1, void* pCliente2)
{
    int orden=0;
    if(pCliente1 != NULL && pCliente2!=NULL)
    {
        orden = strcmp(((Clientes*)pCliente1)->apellido,((Clientes*)pCliente2)->apellido);
    }
    return orden;
}

