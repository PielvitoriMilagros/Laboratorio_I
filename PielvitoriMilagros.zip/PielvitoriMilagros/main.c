#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "funciones.h"
#include "Clientes.h"
#include "Ventas.h"
#include "Productos.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.bin (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.bin (modo binario).
    10. Salir
*****************************************************/


int main()
{
    int option = 0;
    LinkedList* listaClientes = ll_newLinkedList();
    LinkedList* listaVentas = ll_newLinkedList();
    LinkedList* listaProductos = ll_newLinkedList();

    controller_loadFromText("clientes.txt",listaClientes,1);
    controller_loadFromText("ventas.txt",listaVentas,2);
    controller_addProductos(listaProductos);


    do
    {
        printf("\nMenu:");
        printf("\n1. Alta de cliente");
        printf("\n2. Modificaci�n de cliente");
        printf("\n3. Baja de cliente");
        printf("\n4. Listar clientes");
        printf("\n5. Realizar una venta");
        printf("\n6. Anular una venta");
        printf("\n7. Informar ventas");
        printf("\n8. Informar ventas por producto");
        printf("\n9. Generar informe de ventas");
        printf("\n10. Informar cantidad de ventas por cliente");
        printf("\n11. Salir");

        getIntInRange(&option,"\nIngrese opcion: ","Error",1,11,3);
        switch(option)
        {
        case 1:

            if(controller_addCliente(listaClientes) == 0)
            {
                printf("\nSe cargo correctamente el cliente\n");
            }
            else
            {
                printf("\nNo se pudo cargar el cliente\n");
            }
            break;
        case 2:
            if (ll_len(listaClientes) > 0)
            {
                if(controller_editCliente(listaClientes) == 0)
                {
                    printf("\nCliente modificado\n");
                }
                else
                {
                    printf("\nNo se modifico el cliente\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 3:
            if (ll_len(listaClientes) > 0)
            {
                if(controller_removeCliente(listaClientes,listaVentas) == 0)
                {
                    printf("\nCliente eliminado\n");
                }
                else
                {
                    printf("\nNo se elimino el cliente\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 4:
            if (ll_len(listaClientes) > 0)
            {
                controller_sortClientes(listaClientes);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 5:
            if(controller_addVenta(listaVentas,listaClientes,listaProductos) == 0)
            {
                printf("\nSe cargo correctamente la venta\n");
            }
            else
            {
                printf("\nNo se pudo cargar la venta\n");
            }
            break;
        case 6:
            if (ll_len(listaVentas) > 0)
            {
                if(controller_removeVenta(listaVentas) == 0)
                {
                    printf("\nVenta eliminada eliminado\n");
                }
                else
                {
                    printf("\nNo se elimino la venta\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 7:
            if (ll_len(listaVentas) > 0)
            {
                if(!controller_ListVentas(listaVentas,listaClientes,listaProductos)==0)
                    printf("\nProblema al realizar el informe\n");
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 8:
            if (ll_len(listaVentas) > 0)
            {
                controller_ListVentasPorProducto(listaVentas,listaClientes,listaProductos);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 9:
            if(ll_len(listaVentas)> 0)
            {
                if(controller_saveAsText("informe.txt",listaVentas,listaClientes,listaProductos) == 0)
                {
                    printf("\nSe grabo el archivo informe.txt\n");
                }
                else
                {
                    printf("\nNo se pudo guardar el archivo\n");
                }
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        case 10:
            if (ll_len(listaVentas) > 0)
            {
                controller_ListVentasPorCliente(listaVentas,listaClientes,listaProductos);
            }
            else
            {
                printf("\nNo se encontraron registros\n");
            }
            break;
        }
    }
    while(option != 11);

    return 0;
}
