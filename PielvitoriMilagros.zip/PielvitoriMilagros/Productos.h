#ifndef productos_H_INCLUDED
#define productos_H_INCLUDED
typedef struct
{
    int id;
    char descripcion[50];
    float precioUnitario;
}Productos;

Productos* producto_new(void);
Productos* producto_newParametros(char* idStr,char* descripcionStr,char* precioUnitarioStr);
void producto_delete(Productos* producto);

int producto_setId(Productos* this,int id);
int producto_getId(Productos* this,int* id);

int producto_setDescripcion(Productos* this,char* descripcion);
int producto_getDescripcion(Productos* this,char* descripcion);

int producto_setPrecioUnitario(Productos* this,float precioUnitario);
int producto_getPrecioUnitario(Productos* this,float* precioUnitario);

#endif // ventas_H_INCLUDED



