#include "Clientes.h"
#include "Ventas.h"
#include "LinkedList.h"

int controller_loadFromText(char* path , LinkedList* pArrayList, int opc);
//int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee);
int controller_addCliente(LinkedList* pArrayListClientes);
int controller_getLastIdClientes(LinkedList* pArrayListClientes);
int controller_editCliente(LinkedList* pArrayListClientes);
int controller_showCliente(Clientes* pCliente,int llamado);
int controller_findByIdCliente(LinkedList* pArrayListClientes, int id);
int controller_removeCliente(LinkedList* pArrayListClientes,LinkedList* pArrayListVentas);
int controller_sortClientes(LinkedList* pArrayListClientes);
int controller_ListClientes(LinkedList* pArrayListClientes);
int controller_saveAsTextClientes(LinkedList* pArrayListClientes);

int controller_addVenta(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos);
int controller_getLastIdVentas(LinkedList* pArrayListVentas);
int controller_removeVenta(LinkedList* pArrayListVentas);
int controller_findByIdVenta(LinkedList* pArrayListVentas, int id);
int controller_ListVentas(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos);
int controller_showVenta(Ventas* pVenta,LinkedList* pArrayListClientes,LinkedList* pArrayProductos);
int controller_saveAsTextVentas(LinkedList* pArrayListVentas);

int controller_ListVentasPorProducto(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos);
int controller_ListVentasPorCliente(LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos);

int controller_addProductos(LinkedList* pArrayProductos);
int controller_findByIdProducto(LinkedList* pArrayProductos, int id);

int controller_saveAsText(char* path , LinkedList* pArrayListVentas,LinkedList* pArrayListClientes,LinkedList* pArrayProductos);
/*int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee);


*/

