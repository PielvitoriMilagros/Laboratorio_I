#ifndef ventas_H_INCLUDED
#define ventas_H_INCLUDED
typedef struct
{
    int id_venta;
    int id_cliente;
    int codProducto;
    int cantProducto;
    float precioUnitario;
}Ventas;

Ventas* venta_new(void);
Ventas* venta_newParametros(char* idVentaStr,char* idClienteStr,char* codProducto,char* cantProducto, char* precioUnitario);
void venta_delete(Ventas* venta);

int venta_setIdVenta(Ventas* this,int id_venta);
int venta_getIdVenta(Ventas* this,int* id_venta);

int venta_setIdCliente(Ventas* this,int id_cliente);
int venta_getIdCliente(Ventas* this,int* id_cliente);

int venta_setCodProducto(Ventas* this,int codProducto);
int venta_getCodProducto(Ventas* this,int* codProducto);

int venta_setCantProducto(Ventas* this,int cantProducto);
int venta_getCantProducto(Ventas* this,int* cantProducto);

int venta_setPrecioUnitario(Ventas* this,float precioUnitario);
int venta_getPrecioUnitario(Ventas* this,float* precioUnitario);

#endif // ventas_H_INCLUDED


