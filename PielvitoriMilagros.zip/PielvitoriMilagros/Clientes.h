#ifndef clientes_H_INCLUDED
#define clientes_H_INCLUDED
typedef struct
{
    int id;
    char nombre[128];
    char apellido[128];
    int dni;
}Clientes;

Clientes* cliente_new(void);
Clientes* cliente_newParametros(char* idStr,char* nombreStr,char* apellidoStr,char* dniStr);
void cliente_delete(Clientes* cliente);

int cliente_setId(Clientes* this,int id);
int cliente_getId(Clientes* this,int* id);

int cliente_setNombre(Clientes* this,char* nombre);
int cliente_getNombre(Clientes* this,char* nombre);

int cliente_setApellido(Clientes* this,char* apellido);
int cliente_getApellido(Clientes* this,char* apellido);

int cliente_setDni(Clientes* this,int dni);
int cliente_getDni(Clientes* this,int* dni);

int cliente_compareSurname(void* pCliente1, void* pCliente2);
#endif // cliente_H_INCLUDED

