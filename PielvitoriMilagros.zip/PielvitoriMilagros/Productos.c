#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Productos.h"
#include "funciones.h"

Productos* producto_new(void)
{
    return (Productos*)malloc(sizeof(Productos));
}

Productos* producto_newParametros(char* idStr,char* descripcionStr,char* precioUnitarioStr)
{
    Productos* newProducto=NULL;
    Productos* auxProducto=NULL;

    if(idStr != NULL && descripcionStr != NULL && precioUnitarioStr != NULL)
    {
        auxProducto = producto_new();
        if(auxProducto != NULL)
        {
            if(
                producto_setId(auxProducto,atoi(idStr))+
                producto_setDescripcion(auxProducto,descripcionStr)+
                producto_setPrecioUnitario(auxProducto,atof(precioUnitarioStr)) == 0)
            {
                newProducto = auxProducto;
            }
            else
            {
                producto_delete(auxProducto);
            }
        }
    }

    return newProducto;
}

void producto_delete(Productos* this)
{
    if(this != NULL)
        free(this);
}


int producto_setId(Productos* this,int id)
{
    int retorno=-1;
    if(this != NULL && id >= 0)
    {
        this->id = id;
        retorno = 0;
    }
    return retorno;
}
int producto_getId(Productos* this,int* id)
{
    int retorno=-1;
    if(this != NULL && id != NULL)
    {
        *id = this->id;
        retorno = 0;
    }
    return retorno;
}

int producto_setDescripcion(Productos* this,char* descripcion)
{
    int retorno=-1;
    if(this != NULL && descripcion != NULL)
    {
        strcpy(this->descripcion,descripcion);
        retorno = 0;
    }
    return retorno;
}
int producto_getDescripcion(Productos* this,char* descripcion)
{
    int retorno=-1;
    if(this != NULL && descripcion != NULL)
    {
        strcpy(descripcion,this->descripcion);
        retorno = 0;
    }
    return retorno;
}

int producto_setPrecioUnitario(Productos* this,float precioUnitario)
{
    int retorno=-1;
    if(this != NULL && precioUnitario >= 0)
    {
        this->precioUnitario = precioUnitario;
        retorno = 0;
    }
    return retorno;
}
int producto_getPrecioUnitario(Productos* this,float* precioUnitario)
{
    int retorno=-1;
    if(this != NULL && precioUnitario != NULL)
    {
        *precioUnitario = this->precioUnitario;
        retorno = 0;
    }
    return retorno;
}


