#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"

int main()
{
    LinkedList* listaVentas = ll_newLinkedList();

    printf("BIENVENIDO AL SISTEMA DE REVELADO DIGITAL\n");

    if(controller_loadFromText("data.csv",listaVentas)== 0)
        printf("\n\nEl archivo fue cargado correctamente\n");

    if(controller_saveAsText("informes.txt",listaVentas) == 0)
        printf("\nSe genero el Informe de Ventas\n");


    return 0;
}
