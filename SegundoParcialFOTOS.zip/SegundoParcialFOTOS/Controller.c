#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Ventas.h"
#include "parser.h"
#include "funciones.h"


/** \brief Carga los datos de las ventas desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVentas LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListVentas)
{
    FILE* pArch=NULL;
    int len=0;
    int retorno = -1;

    if(path != NULL && pArrayListVentas != NULL)
    {
        pArch = fopen(path,"rw");
        if(pArch != NULL)
        {
            if(parser_VentasFromText(pArch,pArrayListVentas)==0)
            {
                len = ll_len(pArrayListVentas);
                printf("Se cargaron %d registros",len);
                retorno = 0;
            }
        }

        fclose(pArch);
    }

    return retorno;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVentas LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path, LinkedList* pArrayListVentas)
{
    int retorno=-1;
    int len=0;
    int i;
    int auxId;
    char bufferFecha[50];
    char bufferTipo[50];
    int auxCantidad;
    float auxPrecio;
    char bufferCuit[50];

    int cantTotal=0;
    int masDeCientoCincuenta=0;
    int masDeTrescientos=0;
    int cantidadPolaroid;

    Ventas* pVentas;

    FILE* pArch=NULL;

    if(path != NULL && pArrayListVentas != NULL)
    {
        pArch = fopen(path,"w");

        if(pArch != NULL)
        {
            len = ll_len(pArrayListVentas);
            if(len>0)
            {
                for(i=0; i<len; i++)
                {
                    pVentas = ll_get(pArrayListVentas,i);
                    venta_getId(pVentas,&auxId);
                    venta_getFechaVenta(pVentas,bufferFecha);
                    venta_getTipoFoto(pVentas,bufferTipo);
                    venta_getCantidad(pVentas,&auxCantidad);
                    venta_getPrecioUnitario(pVentas,&auxPrecio);
                    venta_getCuitCliente(pVentas,bufferCuit);

                    cantTotal+=auxCantidad;
                    if(auxCantidad * auxPrecio > 150)
                        masDeCientoCincuenta++;
                    if(auxCantidad * auxPrecio > 300)
                        masDeTrescientos++;

                    if(strcmp(bufferTipo,"POLAROID_11x9") == 0 || strcmp(bufferTipo,"POLAROID_10x10")==0)
                        cantidadPolaroid+=auxCantidad;
              }
                fprintf(pArch,"********************\nInforme de ventas\n********************\n- Cantidad de fotos reveladas totales: %d\n- Cantidad de ventas por un monto mayor a $150: %d\n- Cantidad de ventas por un monto mayor a $300: %d\n- Cantidad de fotos polaroids reveladas: %d\n********************",
                        cantTotal,masDeCientoCincuenta,masDeTrescientos,cantidadPolaroid);
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}

/** \brief Guarda los datos de los empleados en el archivo data.bin (modo binario).
 *
 * \param path char*
 * \param pArrayListVentas LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path, LinkedList* pArrayListVentas)
{
    int retorno=-1;
    int len=0;
    int i;

    Ventas* pVentas;
    FILE* pArch=NULL;

    if(path != NULL && pArrayListVentas != NULL)
    {
        pArch = fopen(path,"wb");
        if(pArch != NULL)
        {
            len = ll_len(pArrayListVentas);
            if(len>0)
            {
                for(i=0; i<len; i++)
                {
                    pVentas = ll_get(pArrayListVentas,i);
                    fwrite(pVentas,sizeof(Ventas),1,pArch);
                }
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}


