#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Ventas.h"
#include "parser.h"
#include "funciones.h"


/** \brief Carga los datos de las ventas desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVentas LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListVentas)
{
    FILE* pArch=NULL;
    int len=0;
    int retorno = -1;

    if(path != NULL && pArrayListVentas != NULL)
    {
        pArch = fopen(path,"rw");
        if(pArch != NULL)
        {
            if(parser_VentasFromText(pArch,pArrayListVentas)==0)
            {
                len = ll_len(pArrayListVentas);
                printf("Se cargaron %d registros",len);
                retorno = 0;
            }
        }

        fclose(pArch);
    }

    return retorno;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVentas LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path, LinkedList* pArrayListVentas)
{
    int retorno=-1;

    int cantTotal;
    int masDeCientoCincuenta;
    int masDeTrescientos;
    int cantidadPolaroid=0;

    FILE* pArch=NULL;

    if(path != NULL && pArrayListVentas != NULL)
    {
        pArch = fopen(path,"w");

        if(pArch != NULL)
        {
            cantTotal=ll_count(pArrayListVentas,controller_validaCantidadFotos);
            masDeCientoCincuenta=ll_count(pArrayListVentas,controller_mayorACientoCincuenta);
            masDeTrescientos=ll_count(pArrayListVentas,controller_mayorATrescientos);
            fprintf(pArch,"********************\nInforme de ventas\n********************\n- Cantidad de fotos reveladas totales: %d\n- Cantidad de ventas por un monto mayor a $150: %d\n- Cantidad de ventas por un monto mayor a $300: %d\n- Cantidad de fotos polaroids reveladas: %d\n********************",
                    cantTotal,masDeCientoCincuenta,masDeTrescientos,cantidadPolaroid);

            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}

int controller_validaCantidadFotos(void* pVenta)
{
    int retorno=0;
    int cantidad;

    venta_getCantidad(pVenta,&cantidad);
    retorno=cantidad;

    return retorno;
}

int controller_mayorACientoCincuenta(void* pVenta)
{
    int retorno=0;
    int cantidad;
    float auxPrecio;

    venta_getPrecioUnitario(pVenta,&auxPrecio);
    cantidad=controller_validaCantidadFotos(pVenta);

    if(auxPrecio * cantidad > 150)
        retorno=1;

    return retorno;
}


int controller_mayorATrescientos(void* pVenta)
{
    int retorno=0;
    int cantidad;
    float auxPrecio;

    venta_getPrecioUnitario(pVenta,&auxPrecio);
    cantidad=controller_validaCantidadFotos(pVenta);

    if(auxPrecio * cantidad > 300)
        retorno=1;

    return retorno;
}





/** \brief Guarda los datos de los empleados en el archivo data.bin (modo binario).
 *
 * \param path char*
 * \param pArrayListVentas LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path, LinkedList* pArrayListVentas)
{
    int retorno=-1;
    int len=0;
    int i;

    Ventas* pVentas;
    FILE* pArch=NULL;

    if(path != NULL && pArrayListVentas != NULL)
    {
        pArch = fopen(path,"wb");
        if(pArch != NULL)
        {
            len = ll_len(pArrayListVentas);
            if(len>0)
            {
                for(i=0; i<len; i++)
                {
                    pVentas = ll_get(pArrayListVentas,i);
                    fwrite(pVentas,sizeof(Ventas),1,pArch);
                }
            }
            retorno=0;
            fclose(pArch);
        }
    }

    return retorno;
}


