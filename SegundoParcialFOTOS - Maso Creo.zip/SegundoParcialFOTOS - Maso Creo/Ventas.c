#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Ventas.h"
#include "funciones.h"


Ventas* venta_new(void)
{
    return (Ventas*)malloc(sizeof(Ventas));
}

Ventas* venta_newParametros(char* idStr,char* fechaStr,char* tipoFotoStr,char* cantStr,char* precioStr,char* cuitStr)
{
    Ventas* newVentas=NULL;
    Ventas* auxVentas=NULL;

    if(idStr != NULL && fechaStr != NULL && tipoFotoStr != NULL && cantStr != NULL && precioStr != NULL && cuitStr != NULL)
    {
        auxVentas = venta_new();
        if(auxVentas != NULL)
        {
            if( venta_setId(auxVentas,atoi(idStr))+
                    venta_setFechaVenta(auxVentas,fechaStr)+
                    venta_setTipoFoto(auxVentas,tipoFotoStr)+
                    venta_setCantidad(auxVentas,atoi(cantStr))+
                    venta_setPrecioUnitario(auxVentas,atoi(precioStr))+
                    venta_setCuitCliente(auxVentas,cuitStr) == 0)
            {
                newVentas = auxVentas;
            }
            else
            {
                venta_delete(auxVentas);
            }
        }
    }

    return newVentas;
}


int venta_setId(Ventas* this,int id)
{
    int retorno=-1;
    if(this != NULL && id >= 0)
    {
        this->id = id;
        retorno = 0;
    }
    return retorno;
}
int venta_getId(Ventas* this,int* id)
{
    int retorno=-1;
    if(this != NULL && id != NULL)
    {
        *id = this->id;
        retorno = 0;
    }
    return retorno;
}

char venta_setFechaVenta(Ventas* this,char* fechaVenta)
{
    int retorno=-1;
    if(this != NULL && fechaVenta != NULL)
    {
        strcpy(this->fechaVenta,fechaVenta);
        retorno = 0;
    }
    return retorno;
}
char venta_getFechaVenta(Ventas* this,char* fechaVenta)
{
    int retorno=-1;
    if(this != NULL && fechaVenta != NULL)
    {
        strcpy(fechaVenta,this->fechaVenta);
        retorno = 0;
    }
    return retorno;
}

char venta_setTipoFoto(Ventas* this,char* tipoFoto)
{
    int retorno=-1;
    if(this != NULL && tipoFoto != NULL)
    {
        strcpy(this->tipoFoto,tipoFoto);
        retorno = 0;
    }
    return retorno;
}
char venta_getTipoFoto(Ventas* this,char* tipoFoto)
{
    int retorno=-1;
    if(this != NULL && tipoFoto != NULL)
    {
        strcpy(tipoFoto,this->tipoFoto);
        retorno = 0;
    }
    return retorno;
}

int venta_setCantidad(Ventas* this,int cantidad)
{
    int retorno=-1;
    if(this != NULL && cantidad >= 0)
    {
        this->cantidad = cantidad;
        retorno = 0;
    }
    return retorno;
}
int venta_getCantidad(Ventas* this,int* cantidad)
{
    int retorno=-1;
    if(this != NULL && cantidad != NULL)
    {
        *cantidad = this->cantidad;
        retorno = 0;
    }
    return retorno;
}

float venta_setPrecioUnitario(Ventas* this,float precioUnitario)
{
    int retorno=-1;
    if(this != NULL && precioUnitario >= 0)
    {
        this->precioUnitario = precioUnitario;
        retorno = 0;
    }
    return retorno;
}
float venta_getPrecioUnitario(Ventas* this,float* precioUnitario)
{
    int retorno=-1;
    if(this != NULL && precioUnitario != NULL)
    {
        *precioUnitario = this->precioUnitario;
        retorno = 0;
    }
    return retorno;
}

char venta_setCuitCliente(Ventas* this,char* cuitCliente)
{
    int retorno=-1;
    if(this != NULL && cuitCliente != NULL)
    {
        strcpy(this->cuitCliente,cuitCliente);
        retorno = 0;
    }
    return retorno;
}
char venta_getCuitCliente(Ventas* this,char* cuitCliente)
{
    int retorno=-1;
    if(this != NULL && cuitCliente != NULL)
    {
        strcpy(cuitCliente,this->cuitCliente);
        retorno = 0;
    }
    return retorno;
}


void venta_delete(Ventas* this)
{
    if(this != NULL)
        free(this);
}


/*
int venta_compareName(void* pVentas1, void* pVentas2)
{
    int orden=0;
    if(pVentas1 != NULL && pVentas2!=NULL)
    {
        orden = strcmp(((Ventas*)pVentas1)->nombre,((Ventas*)pVentas2)->nombre);
    }
    return orden;
}
*/
